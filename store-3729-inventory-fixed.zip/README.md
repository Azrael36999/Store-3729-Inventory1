# Store 3729 Inventory

Backend + Frontend root package (fixed folder layout for Render).
